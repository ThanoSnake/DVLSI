#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xparameters_ps.h"
#include "xaxidma.h"
#include "xtime_l.h"
#include "sleep.h"

//#include "pixels.h" //Input pixels file

#define TX_DMA_ID                 XPAR_PS2PL_DMA_DEVICE_ID
#define TX_DMA_MM2S_LENGTH_ADDR  (XPAR_PS2PL_DMA_BASEADDR + 0x28) // Reports actual number of bytes transferred from PS->PL (use Xil_In32 for report)

#define RX_DMA_ID                 XPAR_PL2PS_DMA_DEVICE_ID
#define RX_DMA_S2MM_LENGTH_ADDR  (XPAR_PL2PS_DMA_BASEADDR + 0x58) // Reports actual number of bytes transferred from PL->PS (use Xil_In32 for report)

#define TX_BUFFER (XPAR_DDR_MEM_BASEADDR + 0x08000000) // 0 + 128MByte
#define RX_BUFFER (XPAR_DDR_MEM_BASEADDR + 0x10000000) // 0 + 256MByte
#define SW_BUFFER (XPAR_DDR_MEM_BASEADDR + 0x12000000)

// for AXI-Lite
#define DEBAYER_IP_BASEADDR XPAR_DEBAYER_0_S00_AXI_BASEADDR

//DMA Structures
XAxiDma AxiDmaTx;
XAxiDma AxiDmaRx;

//Global Image Buffers
uint8_t img1_buffer[128*128];
uint8_t img2_buffer[1024*1024];

void create_image(uint8_t *array, int N) {
    for (int i = 0; i < N*N; i++) {
        array[i] = i % 256;
    }

}

void debayer_sw(const uint8_t *input, uint32_t *output, int N) {
    for (int i = 0; i < N; i++) {
        for (int j =0 ; j < N; j++) {

            uint8_t state1, state2;

            if (i % 2 == 0) state1 = 1;
            else state1 = 0;
            if (j % 2 == 0) state2 = 1;
            else state2 = 0;

            uint8_t P11, P12, P13;
            uint8_t P21, P22, P23;
            uint8_t P31, P32, P33;

            uint16_t sum_vert, sum_hor, sum_cross, sum_diag;

            uint32_t red, green, blue;

            P11 = (i > 0 && j > 0) ? input[N*(i-1) + (j-1)] : 0;
            P12 = (i > 0) ? input[N*(i-1) + j] : 0;
            P13 = (i > 0 && j < (N-1)) ? input[N*(i-1) + (j+1)] : 0;
            P21 = (j > 0) ? input[N*i + (j-1)] : 0;
            P22 = input[N*i + j];
            P23 = (j < (N-1)) ? input[N*i + (j+1)] : 0;
            P31 = (i < (N-1) && j > 0) ? input[N*(i+1) + (j-1)] : 0;
            P32 = (i < (N-1)) ? input[N*(i+1) + j] : 0;
            P33 = (i < (N-1) && j < (N-1)) ? input[N*(i+1) + (j+1)] : 0;

            sum_vert = P12 + P32;
            sum_hor = P21 + P23;

            sum_cross = P12 + P21 + P23 + P32;
            sum_diag = P11 + P13 + P31 + P33;

            if (state1 == 1 && state2 == 1) {
                red = sum_vert >> 1;
                green = P22;
                blue = sum_hor >> 1;
            }

            else if (state1 == 0 && state2 == 0) {
                red = sum_hor >> 1;
                green = P22;
                blue = sum_vert >> 1;
            }

            else if (state1 == 1 && state2 == 0) {
                red = sum_diag >> 2;
                green = sum_cross >> 2;
                blue = P22;
            }

            else {
                red = P22;
                green = sum_cross >> 2;
                blue = sum_diag >> 2;
            }

            output[N*i + j] = (red << 16 | green << 8 | blue);
        }
    }
}

uint32_t decodeN (int N) {
    switch (N) {
        case 1024: return 4;
        case 512:  return 3;
        case 256:  return 2;
        case 128:  return 1;
        case 64:   return 0;
        default:
            printf("ERROR: Unsupported dimension N = %d for Hardware LUT!\n", N);
            return 5;
    }
}

void evaluate_debayer(XAxiDma *TxDma, XAxiDma *RxDma, const uint8_t *input_img, int N) {

    int img_size = N*N;
    int img_bytes_tx = img_size * sizeof(uint8_t);
    int img_bytes_rx = img_size * sizeof(uint32_t); // RGB 32-bit

    XTime preExecCyclesFPGA = 0;
	XTime postExecCyclesFPGA = 0;
	XTime preExecCyclesSW = 0;
	XTime postExecCyclesSW = 0;

    printf("\n=======================================\n");
    printf("Evaluating Image: (%d x %d)\n", N, N);
    printf("=======================================\n");

    volatile uint32_t lut_mode = decodeN(N);
    if (lut_mode == 5) {
        printf("Evaluation aborted due to invalid dimension.\n");
        return;
    }
    volatile uint32_t config = lut_mode | (1 << 3); //image_dim and image_dim_vld = '1'
    Xil_Out32(DEBAYER_IP_BASEADDR + 0x00, config);

    volatile uint32_t dummy_read = Xil_In32(DEBAYER_IP_BASEADDR + 0x00);
    printf("%lu\n", dummy_read);

    for(volatile int delay = 0; delay < 50; delay++);

    config = config & ~(1 << 3); //image_dim_vld = '0'
    Xil_Out32(DEBAYER_IP_BASEADDR + 0x00, config);
    volatile uint32_t dummy_read_low = Xil_In32(DEBAYER_IP_BASEADDR + 0x00);
    printf("%lu\n", dummy_read_low);

    // 3. Προαιρετικά: Μία μικρή καθυστέρηση για να "ανασάνει" το VHDL FSM
    //usleep(10);

    //prepare input pixels. load pixels to TX BUFFER
    uint8_t *tx_ptr = (uint8_t *)TX_BUFFER;
    for (int i = 0; i < img_size; i++) {
        tx_ptr[i] = input_img[i];
    }

    //Διώχνουμε τα δεδομένα από την L1/L2 Cache προς τη DDR για να τα βρει ο DMA
    Xil_DCacheFlushRange((INTPTR)TX_BUFFER, img_bytes_tx);

    printf("HW\n");
    // Step 3 : Perform FPGA processing
    XTime_GetTime(&preExecCyclesFPGA);
    //      3a: Setup RX-DMA transaction
    XAxiDma_SimpleTransfer(RxDma, (UINTPTR)RX_BUFFER, img_bytes_rx, XAXIDMA_DEVICE_TO_DMA);
    //      3b: Setup TX transaction
    XAxiDma_SimpleTransfer(TxDma, (UINTPTR)TX_BUFFER, img_bytes_tx, XAXIDMA_DMA_TO_DEVICE);
        //      3c: Wait for TX-DMA & RX-DMA to finish
    while (XAxiDma_Busy(TxDma, XAXIDMA_DMA_TO_DEVICE));
    while (XAxiDma_Busy(RxDma, XAXIDMA_DEVICE_TO_DMA));
    XTime_GetTime(&postExecCyclesFPGA);

    //Ενημερώνουμε την Cache ότι η DDR άλλαξε (έγραψε ο DMA)
    Xil_DCacheInvalidateRange((INTPTR)RX_BUFFER, img_bytes_rx);
    printf("SW");
    // Step 5: Perform SW processing
    XTime_GetTime(&preExecCyclesSW);
    debayer_sw(input_img, (uint32_t *)SW_BUFFER, N);
    XTime_GetTime(&postExecCyclesSW);

    // Step 6: Compare FPGA and SW results
    //     6a: Report total percentage error
    int errors = 0;
    uint32_t *fpga_res = (uint32_t *)RX_BUFFER;
    uint32_t *sw_res = (uint32_t *)SW_BUFFER;

    for(int i = 0; i < img_size; i++) {
        if (fpga_res[i] != sw_res[i]) {
            errors++;
            if(errors < 5) { //Print first 5 errors
                 printf("Mismatch at index %d: FPGA=0x%08lX, SW=0x%08lX\n", i, fpga_res[i], sw_res[i]);
            }
        }
    }

    double fpga_cycles = (double)(postExecCyclesFPGA - preExecCyclesFPGA);
    double sw_cycles = (double)(postExecCyclesSW - preExecCyclesSW);

    //     6b: Report FPGA execution time in cycles (use preExecCyclesFPGA and postExecCyclesFPGA)
    //     6c: Report SW execution time in cycles (use preExecCyclesSW and postExecCyclesSW)
    //     6d: Report speedup (SW_execution_time / FPGA_exection_time)
    printf("\n--- Performance Stats ---\n");
    printf("FPGA Cycles:       %.0f\n", fpga_cycles);
    printf("SW Cycles:         %.0f\n", sw_cycles);
    printf("Hardware Speedup:  %.2f x\n", sw_cycles / fpga_cycles);
    printf("Validation Errors: %d\n", errors);
}


/* User application global variables & defines */

int main()
{
	Xil_DCacheDisable();
    int Status;

	printf("HELLO 1\r\n");
	// User application local variables

	init_platform();

    // Step 1: Initialize TX-DMA Device (PS->PL)
    // Step 2: Initialize RX-DMA Device (PL->PS)
    XAxiDma_Config *CfgPtr;

    // Initialize TX DMA
    CfgPtr = XAxiDma_LookupConfig(TX_DMA_ID);
    Status = XAxiDma_CfgInitialize(&AxiDmaTx, CfgPtr);
    if (Status != XST_SUCCESS) {xil_printf("TX DMA Init Failed\n"); return XST_FAILURE; }

    // Initialize RX DMA
    CfgPtr = XAxiDma_LookupConfig(RX_DMA_ID);
    Status = XAxiDma_CfgInitialize(&AxiDmaRx, CfgPtr);
    if (Status != XST_SUCCESS) { xil_printf("RX DMA Init Failed\n"); return XST_FAILURE; }

    // Create Test Images / Different dimensions
    create_image(img1_buffer, 128);
    create_image(img2_buffer, 1024);

    // Evaluation Phase
    evaluate_debayer(&AxiDmaTx, &AxiDmaRx, img2_buffer, 1024);
    uint32_t status_rx = XAxiDma_ReadReg(AxiDmaTx.RegBase, XAXIDMA_SR_OFFSET);
    printf("RX DMA Status after image 1: 0x%08lX\n", status_rx);
    evaluate_debayer(&AxiDmaTx, &AxiDmaRx, img1_buffer, 128);

    cleanup_platform();
    return 0;
}
