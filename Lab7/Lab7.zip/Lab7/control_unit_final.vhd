library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity control_unit is
    port (
        clk                 : in  std_logic;
        rst_n               : in  std_logic;
        new_image           : in  std_logic;
        valid_in            : in  std_logic;
        image_dim_vld_pulse : in  std_logic; --new
        image_dim           : in  std_logic_vector(2 downto 0);  --new

        wr_en           : out std_logic_vector(2 downto 0);
        rd_en           : out std_logic_vector(2 downto 0);
        state1          : out std_logic_vector(3 downto 0);
        state2          : out std_logic_vector(1 downto 0);
        valid_out       : out std_logic;
        image_finished  : out std_logic;
        shift_enable    : out std_logic;
        fifo_clear      : out std_logic; --new
        ready           : out std_logic  --new
    );
end entity;

architecture arc of control_unit is

    -- FSM's states declaration
    type state_type is (ST_IDLE, ST_LOADING, ST_NORMAL, ST_DRAINING, ST_CLEAR);
    signal current_state    : state_type;

    -- new begin
    signal flag_configured  : std_logic := '0';
    signal N                : integer range 0 to 1024     := 0;
    signal squared_N        : integer range 0 to 1048576  := 0; -- 1024 * 1024
    signal doubled_N        : integer range 0 to 2048     := 0;  
    -- new end
    signal counter          : integer := 0;
    signal i                : integer := 0;
    signal j                : integer := 0;

    signal valid_in_del     : std_logic := '0';

begin

    -- State Transitions
    process(clk, rst_n)
    begin
        if rst_n = '0' then
            current_state <= ST_IDLE;
            counter <= 0;
            i <= 0;
            j <= 0;
            flag_configured <= '0'; --new
            fifo_clear <= '0'; --new
        elsif rising_edge(clk) then          

            if image_dim_vld_pulse = '1' and current_state = ST_IDLE then
                case image_dim is
                    when "000" =>
                        N <= 64;
                        squared_N <= 4096;
                        doubled_N <= 128;
                        flag_configured <= '1';
                    when "001" =>
                        N <= 128;
                        squared_N <= 16384;
                        doubled_N <= 256;
                        flag_configured <= '1';
                    when "010" =>
                        N <= 256;
                        squared_N <= 65536;
                        doubled_N <= 512;
                        flag_configured <= '1';
                    when "011" =>
                        N <= 512;
                        squared_N <= 262144;
                        doubled_N <= 1024;
                        flag_configured <= '1';
                    when "100" =>
                        N <= 1024;
                        squared_N <= 1048576;
                        doubled_N <= 2048;
                        flag_configured <= '1';
                    when others =>
                        flag_configured <= '0';
                end case;
            end if;

            case current_state is
                when ST_IDLE =>
                    counter <= 0;
                    fifo_clear <= '0'; 
                    if new_image = '1' and valid_in = '1' and (flag_configured = '1' or image_dim_vld_pulse = '1') then --new
                        current_state <= ST_LOADING;
                        counter <= 1;
                    end if;

                when ST_LOADING =>
                    if valid_in = '1' then 
                        counter <= counter + 1;
                        if counter = doubled_N + 1 then 
                            current_state <= ST_NORMAL;
                            i <= 0;
                            j <= 0;
                        end if;
                    end if;


                when ST_NORMAL =>
                    if valid_in = '1' then 
                        counter <= counter + 1;
                            
                        if j = N-1 then
                            i <= i + 1;
                            j <= 0;
                        else
                            j <= j + 1;
                        end if;
                    end if;

                    valid_in_del <= valid_in;

                    if counter = squared_N-1 and valid_in = '1' then -- from squared_N-2 to squared_N-1 correction
                        current_state <= ST_DRAINING;
                    end if;


                when ST_DRAINING =>
                    if counter = squared_N+doubled_N+2 then
                        current_state <= ST_CLEAR;
                        counter <= 0;
                        flag_configured <= '0';
                        fifo_clear <= '1'; --clear fifos
                    else
                        counter <= counter + 1;
                        
                        if j = N-1 then
                            i <= i + 1;
                            j <= 0;
                        else
                            j <= j + 1;
                        end if;
                    end if;

                when ST_CLEAR =>
                    if counter = 10 then
                        current_state <= ST_IDLE;
                        fifo_clear <= '0'; --stop clearing fifo
                    else
                        counter <= counter + 1;
                    end if;

                when others =>
                    current_state <= ST_IDLE;
            end case;
        end if;
    end process;

    wr_en(0) <= valid_in;
    shift_enable <= '1' when (valid_in = '1' or current_state = ST_DRAINING) else '0';

    rd_en(0) <= '1' when ((counter >= N-1 and valid_in = '1') or current_state = ST_DRAINING) else '0';
    wr_en(1) <= '1' when ((counter >= N and valid_in = '1') or current_state = ST_DRAINING) else '0';

    rd_en(1) <= '1' when ((counter >= doubled_N-1 and valid_in = '1') or current_state = ST_DRAINING) else '0';
    wr_en(2) <= '1' when ((counter >= doubled_N and valid_in = '1') or current_state = ST_DRAINING)  else '0';

    rd_en(2) <= '1' when ((counter >= doubled_N+N-1 and valid_in = '1') or current_state = ST_DRAINING) else '0';

    --Boundary Decoder
    state1(3) <= '1' when i=0   else '0'; --Top
    state1(2) <= '1' when j=0   else '0'; --Left
    state1(1) <= '1' when i=N-1 else '0'; --Bottom
    state1(0) <= '1' when j=N-1 else '0'; --Right

    --Color Decoder
    state2(1) <= '1' when (i mod 2)=0 else '0'; 
    state2(0) <= '1' when (j mod 2)=0 else '0';
    --G1 "11"
    --B  "10"
    --R  "01"
    --G2 "00"

    valid_out       <= '1' when (counter >= doubled_N+3 and counter <= squared_N+doubled_N+2 and (valid_in_del = '1' or current_state = ST_DRAINING)) else '0';
    image_finished  <= '1' when counter = squared_N+doubled_N+2 else '0';

    ready <= '1' when (flag_configured = '1' and (current_state = ST_IDLE or current_state = ST_LOADING or current_state = ST_NORMAL)) else '0'; --new/ TREADY usage in AXI
end architecture;
